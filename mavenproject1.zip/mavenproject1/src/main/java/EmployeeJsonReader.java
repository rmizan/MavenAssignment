
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.jar.Attributes.Name;
import static jdk.nashorn.internal.objects.ArrayBufferView.buffer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mrahman1s
 */
public class EmployeeJsonReader {

    public static void main(String[] args) throws IOException {

        String myurl = "https://www.w3schools.com/angular/customers.php";

        // Connect to the URL using java's native library
        URL url = new URL(myurl);
        HttpURLConnection request = (HttpURLConnection) url.openConnection();
        request.connect();

        // Convert to a JSON object to print data
        JsonParser jp = new JsonParser(); //from gson
        JsonElement root = jp.parse(new InputStreamReader((InputStream) request.getContent())); //Convert the input stream to a json element
        JsonObject rootobj = root.getAsJsonObject();
        System.out.println(rootobj);

        //JSONObject jsonObject = (JSONObject) obj;
        //  System.out.println(jsonObject);
        JsonArray jsa = rootobj.getAsJsonArray("records");
        System.out.println(" Json Objects");
        List<Employee> employees = new ArrayList();
        for (int i = 0; i < jsa.size(); i++) {
            Employee employee = new Employee();
            JsonObject jsonObject = jsa.get(i).getAsJsonObject();

            System.out.print(jsonObject.get("Name") + " ");
            employee.setName(jsonObject.get("Name").getAsString());
            System.out.print(jsonObject.get("City") + " ");
            employee.setName(jsonObject.get("City").getAsString());
            System.out.println(jsonObject.get("Country"));
            employee.setName(jsonObject.get("Country").getAsString());
            employees.add(employee);
        }

    }

}
